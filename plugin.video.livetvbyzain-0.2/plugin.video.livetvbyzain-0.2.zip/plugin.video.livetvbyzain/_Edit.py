import xbmcaddon

MainBase = 'http://pastebin.com/raw/47Z8hXAG'
addon = xbmcaddon.Addon('plugin.video.livetvbyzain')